import tkinter
import random
import sys


class Sjsu:
    """
    class to play the SJSU_INVADERS game

    Argument:
    parent: (tkinter.TK) the root window object
    difficulty: (Integer) the rate at which enemies are spawned
    username: (String) the name of the player

    Attributes:
        velocity: (Integer) the x direction of sammy. Set to -1,0,or 1
        missiles: (List[Integer]) A list of the ids of the missle ovals
        enemies: (Tuple(Integer,Integer) A Tuple of the ids of the circle
            object of the course and the label inside.
        GPA: (Float) the user's current score
        go: (Boolean) shows if the game is paused
        time: (Integer) tracks the number of times animate() is called
            to spawn enemies accordingly
        enemy_health: (Dictionary[Tuple:Integer]) dictionary from the tuples in
            the enemies attribute to their remaining health
        courses: (Tuple[String])the ordered list of courses as they spawn
    """

    def __init__(self, parent, difficulty, username):
        self.parent = parent
        self.difficulty = difficulty
        self.username = username
        self.velocity = 0
        self.sammy_image = tkinter.PhotoImage(file='sjsu.png')
        self.missiles = []
        self.enemies = []
        self.canvas = tkinter.Canvas(parent, width=1000, height=1000,
                                     background='black')
        self.sammy = self.canvas.create_image(100, 750, image=self.sammy_image)
        self.GPA = 4.0
        self.go = True
        self.label = tkinter.Label(parent,
                    text=f'Hello {self.username} Your GPA is: {self.GPA:.2f}')
        self.reset_button = tkinter.Button(parent, text='Reset', width=40,
                                           command=self.reset)
        self.time = 0
        self.enemy_health = dict()
        self.courses = (
            'CS 146', 'CS 151', 'CS 152', 'CS 156', 'CS 149', 'CS 166',
            'CS 122')
        self.spawn_enemy()
        parent.bind('<Left>', lambda event: self.left())
        parent.bind('<Right>', lambda event: self.right())
        parent.bind('<Up>', lambda event: self.shoot())
        parent.bind('<Escape>', lambda event: self.pause())
        parent.bind('<KeyRelease-Right>', lambda event: self.stop())
        parent.bind('<KeyRelease-Left>', lambda event: self.stop())
        self.animate()
        self.label.pack()
        self.reset_button.pack()
        self.canvas.pack()

    def spawn_enemy(self):
        """
        spawns a enemy at a random x location at y=0
        :return: None
        """
        if (self.time % self.difficulty == 0 and
                self.time < self.difficulty * 6):
            randomx = random.randint(1, 1000 - 100)
            rectangle = self.canvas.create_oval(randomx, 0, randomx + 100, 100,
                                                fill='blue')
            label = self.canvas.create_text((randomx + 50, 50),
                                            text=self.courses[
                                            int(self.time / self.difficulty)],
                                            fill='white',
                                            font="Times 20 italic bold")
            self.enemies.append((rectangle, label))
            self.enemy_health[(rectangle, label)] = 5
        elif (self.time == self.difficulty * 6):
            rectangle = self.canvas.create_oval(0, -100, 1000, 100,
                                                fill='blue')
            label = self.canvas.create_text((500, 50), text=self.courses[
                int(self.time / self.difficulty)], fill='white',
                                            font="Times 20 italic bold")
            self.enemies.append((rectangle, label))
            self.enemy_health[(rectangle, label)] = 20

    def pause(self):
        """
        Pauses the game
        :return: None
        """
        self.go = not self.go

    def reset(self):
        """
        Resets the game
        :return: None
        """
        for missle in self.missiles:
            self.canvas.delete(missle)
        for enemy in self.enemies:
            self.canvas.delete(enemy[0])
            self.canvas.delete(enemy[1])
        self.missiles = []
        self.enemies = []
        self.GPA = 4.0
        self.label.config(
            text=f'Hello {self.username} Your GPA is: {self.GPA:.2f}')
        self.go = True
        self.time = 0
        self.enemy_health = dict()
        self.parent.bind('<Escape>', lambda event: self.pause())
        self.spawn_enemy()

    def right(self):
        """
        Sets sammy to move to the right
        :return: None
        """
        self.velocity = 1

    def left(self):
        """
        Sets sammy to move to the left
        :return: None
        """
        self.velocity = -1

    def stop(self):
        """
        Stops sammy's movement
        :return: None
        """
        self.velocity = 0

    def shoot(self):
        """
        Fires a missle from sammy's current location stright up
        :return: None
        """
        xsammy, ysammy = self.canvas.coords(self.sammy)
        bullet = self.canvas.create_oval(xsammy, ysammy, xsammy + 10,
                                         ysammy + 20, fill='yellow')
        self.missiles.append(bullet)

    def animate(self):
        """
        Checks for collisions between missiles and enemies. If there is a
        collision decrements the enemies health. If health equals 0 removes
        enemy.
        Update enemy position. If they touch the bottom they are deleted
        and the gpa is reduced.
        Game state is updated if the drop below2.0.
        Update sammy's position
        :return:
        """
        if self.go:
            self.time += 1
            self.spawn_enemy()
            for bullet in self.missiles:
                bullet_coords_left, bullet_coords_top, bullet_coords_right,\
                bullet_coords_bottom = self.canvas.coords(bullet)
                for enemy in self.enemies:
                    enemy_coords_left, enemy_coords_top, enemy_coords_right, \
                    enemy_coords_bottom = self.canvas.coords(enemy[0])
                    if (bullet_coords_right > enemy_coords_left and
                        bullet_coords_left < enemy_coords_right) and (
                            bullet_coords_top > enemy_coords_top and
                            bullet_coords_top < enemy_coords_bottom):
                        self.enemy_health[enemy] -= 1
                        self.missiles.remove(bullet)
                        self.canvas.delete(bullet)
                    if (self.enemy_health[enemy] == 0):
                        self.enemies.remove(enemy)
                        self.canvas.delete(enemy[0])
                        self.canvas.delete(enemy[1])
                self.canvas.move(bullet, 0, -2)
            for enemy in self.enemies:
                self.canvas.move(enemy[0], 0, 0.5)
                self.canvas.move(enemy[1], 0, 0.5)
                enemy_coords_left, enemy_coords_top, enemy_coords_right, \
                enemy_coords_bottom = self.canvas.coords(
                    enemy[0])
                if (enemy_coords_bottom >= 1000):
                    self.GPA -= 0.66666666666666
                    self.enemies.remove(enemy)
                    self.canvas.delete(enemy[0])
                    self.canvas.delete(enemy[1])
                    if (self.GPA >= 2.0):
                        self.label.config(
                            text=f'Hello {self.username} '
                                 f'Your GPA is: {self.GPA:.2f}')
                    else:
                        self.label.config(text='Sorry, you flunked out')
                        self.go = False
                        self.parent.bind('<Escape>',
                                         lambda event: self.reset())
                    if (self.time+1000 > self.difficulty * 6 and
                            not self.enemies):
                        self.label.config(
                            text=f'Congradulations {self.username} You '
                                 f'Graduated with a GPA of {self.GPA:.2f}')
            xsammy, ysammy = self.canvas.coords(self.sammy)
            if (xsammy <= 1):
                self.velocity = 1;
            if (xsammy >= 999):
                self.velocity = -1;
            self.canvas.move(self.sammy, self.velocity, 0)
        self.parent.after(1, self.animate)


def main():
    difficulty = str(sys.argv[1]).lower()
    username = str(sys.argv[2])
    if (difficulty == 'easy'):
        difficulty = 1000
    elif (difficulty == 'medium'):
        difficulty = 500
    elif (difficulty == 'hard'):
        difficulty = 250
    else:
        raise Exception(
            'first argument should be a difficulty (easy,medium,hard)')
    root = tkinter.Tk()
    root.title('SJSU INVADERS')
    sjsu_app = Sjsu(root, difficulty, username)
    root.mainloop()


if __name__ == '__main__':
    main()
