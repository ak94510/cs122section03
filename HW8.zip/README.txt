Left Arrow - Move left
Right Arrow - Move Right
Up Arrow - Fire
Escape - Pause

First command line argument: difficulty.
	-choose from easy, medium, and hard
Second command line argument: name
	-Enter your name

Shoot each course until it disapears in order to pass it. Allowing
a course to reach the bottom of the screen will result in a fail and
be reflected in your gpa. If your gpa falls below 2.0 you lose. 
Graduation is about survival >:)